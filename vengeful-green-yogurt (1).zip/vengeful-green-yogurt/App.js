import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';

export default function App() {

  const userData = {
    firstName: "Рулан",
    lastName: "Жексен",
    profession: "Frontend Developer",
    description: "Опытный разработчик.",
    phone: "+7 (747) 301-10-16",
    email: "zhexen.rulan@example.com",
    city: "Павлодар",
    avatarUrl: ""
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        {/* Основная карточка-визитка */}
        <View style={styles.businessCard}>
          
          {/* Фото профиля */}
          <Image 
            source={{ uri: userData.avatarUrl }}
            style={styles.avatar}
          />
          
          {/* Имя и фамилия */}
          <Text style={styles.name}>
            {userData.firstName} {userData.lastName}
          </Text>
          
          {/* Профессия */}
          <Text style={styles.profession}>
            {userData.profession}
          </Text>
          
          {/* Описание */}
          <View style={styles.descriptionContainer}>
            <Text style={styles.description}>
              {userData.description}
            </Text>
          </View>
          
          {/* Разделительная линия */}
          <View style={styles.divider} />
          
          {/* Контактные данные */}
          <View style={styles.contactsContainer}>
            <View style={styles.contactItem}>
              <Text style={styles.contactLabel}>Телефон:</Text>
              <Text style={styles.contactValue}>{userData.phone}</Text>
            </View>
            
            <View style={styles.contactItem}>
              <Text style={styles.contactLabel}>Email:</Text>
              <Text style={styles.contactValue}>{userData.email}</Text>
            </View>
            
            <View style={styles.contactItem}>
              <Text style={styles.contactLabel}>Город:</Text>
              <Text style={styles.contactValue}>{userData.city}</Text>
            </View>
          </View>
        </View>
        
        {/* Дополнительная информация под карточкой */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Готов к новым проектам и сотрудничеству!
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
  },
  container: {
    flex: 1,
    backgroundColor: '#f0f8ff', // Цвет фона экрана
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  businessCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    
    // Тень для карточки (работает на iOS и Android)
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 6, // Тень для Android
    
    // Рамка для дополнительного акцента
    borderWidth: 1,
    borderColor: '#e6f2ff',
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 20,
    borderWidth: 3,
    borderColor: '#4a90e2',
  },
  name: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1a365d',
    textAlign: 'center',
    marginBottom: 8,
  },
  profession: {
    fontSize: 18,
    fontWeight: '600',
    color: '#4a90e2',
    textAlign: 'center',
    marginBottom: 20,
  },
  descriptionContainer: {
    backgroundColor: '#f8faff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    width: '100%',
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    color: '#4a5568',
    textAlign: 'center',
  },
  divider: {
    height: 1,
    backgroundColor: '#e2e8f0',
    width: '100%',
    marginVertical: 20,
  },
  contactsContainer: {
    width: '100%',
  },
  contactItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  contactLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d3748',
  },
  contactValue: {
    fontSize: 16,
    color: '#4a5568',
  },
  footer: {
    marginTop: 30,
    padding: 16,
    backgroundColor: '#4a90e2',
    borderRadius: 12,
    width: '100%',
    maxWidth: 400,
  },
  footerText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    textAlign: 'center',
  },
});